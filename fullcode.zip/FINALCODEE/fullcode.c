char name[]={"Welcome Everyone"};
char name1[]={"seconds"};

unsigned char i,y=0;
unsigned int k=0 ;
signed int j;
unsigned char x=1;
unsigned char len;
void USART_init(void);
void USART_Tx(unsigned char myChar);
void Move(unsigned char);
void Movep(unsigned char);
void myDelay(void);
void mymsDelay(unsigned int x);
//============================
float tick=0;
unsigned int tick2=0;
unsigned int tick3=0;
unsigned int tick4=0;
unsigned int sec10=0;
unsigned int sec=0;
unsigned int sec_1=0;
unsigned int sec10m=0;
unsigned int cntr=0;
//=============================
unsigned char TMR0_F=0;
unsigned char USART_F=0;
unsigned char RCREG1=0;


void TMR0_init(void);

void display(unsigned char a,unsigned char b);

unsigned char ali[70];
void interrupt(){

 if(INTCON&0x04)                                { // will get here every 0.792ms(required delay for the motors)
       TMR0=58;
       cntr++;//for mymsdelayfunc
       tick=tick+0.792;// will increment every 0.792 ms
INTCON = INTCON & 0xFB;  } //�clear�TOIF�

 if(PIR1 & 0x20){
 RCREG1=RCREG;
 USART_F=1;        // my USART Flag
 PIR1 = PIR1 & 0xDF;} // clear the RCIF

                     }

void main() {

y=0;
k=0;

TRISB = 0x00;
PORTB = 0x00;

TRISC = 0x00;

TRISD = 0x00;

TMR0_init();

      display (0x02,0);//Command for change LCD to 4 Bit Mode
      display (0x01,0);//Command for clear screen
      display (0x0c,0);//command for display ON,Cursor OFF,Blink OFF
      display (0x28,0);//Command for4 bit interface, 2 lines, 5x8 font

      display (0x80,0);//Command for Begin Print at 1st Row,1st column
      for(i=0;name[i]!='\0';i++)
      {display (name[i],1);}

      USART_init();
      while(1){
      y=0;
      k=0;
      while(!y){
      if(USART_F==1)        {
      USART_F=0;
                 if(RCREG1==0x29)        {      // disable
                 len=k;
                 y=1;

                                         }

          else {ali[k]=RCREG1;
                k++;}
                              }

      TMR0_init();}
      while(y){
      y=0;
               for(j=1;j<len-4;j++){

                  if(ali[j]==0x27){
                  Move(ali[j-1]);
                  j++;
                  j++;            }

                    else {Movep(ali[j-1]);
                  PORTD=0x00;
                    j++;}
                                     }


      sec=tick/1000;      //seconds
      tick = tick-sec;
      sec_1 = tick/100;   //100m seconds
      tick = tick-sec_1;
      sec10m = tick /10;  //10m seconds

            display (0xC0,0);//Command for Begin Print at 2nd Row,1st column
            display((sec)+0x30,1);
            display('.',1);
            display((sec_1%10)+0x30,1);//-1
            display((sec10m%10)+0x30,1);
            display (0xC6,0);//Command for Begin Print at 2nd Row,5th column
            for(i=0;name1[i]!='\0';i++)
            {display (name1[i],1);}}
           }}

void Movep(unsigned char x){
 switch(x){     //q, w, e are used to make patterns not to solve the cube, it moves every two opposite faces(U-D,F-B,R-L)
   case 'q' :
   USART_Tx('q');

                   USART_Tx(' ');
                   PORTC=PORTC | 0x10;
                   for(i=0;i<100;i++){
                   PORTC=PORTC | 0x20;
                   PORTC=PORTC | 0x08;
                   MyDelay();
                   PORTC=PORTC & 0xDF;
                   PORTC=PORTC & 0xF7;
                   MyDelay();
                 }
                 PORTC=PORTC & 0xEF;

        break;
          case 'w' :
   USART_Tx('w');

                   USART_Tx(' ');
                   PORTC=PORTC | 0x10;
                   for(i=0;i<100;i++){
                   PORTD=PORTD | 0x02;
                   PORTD=PORTD | 0x08;
                   MyDelay();
                   PORTD=PORTD & 0xF7;
                   PORTD=PORTD & 0xFD;
                   MyDelay();
                 }
                 PORTC=PORTC & 0xEF;

        break;


   case 'e' :
   USART_Tx('e');

                   USART_Tx(' ');
                   PORTC=PORTC | 0x10;
                   for(i=0;i<100;i++){
                   PORTC=PORTC | 0x02;
                   PORTD=PORTD | 0x20;
                   MyDelay();
                   PORTC=PORTC & 0xFD;
                    PORTD=PORTD & 0xDF;
                   MyDelay();
                 }
                 PORTC=PORTC & 0xEF;

        break;



   case 'R' :      USART_Tx('R');

                   USART_Tx(' ');
                   PORTC=PORTC | 0x10;
                   for(i=0;i<50;i++){
                   PORTC=PORTC | 0x20;

                   MyDelay();
                   PORTC=PORTC & 0xDF;

                   MyDelay();
                 }
                 PORTC=PORTC & 0xEF;
   break;
   case 'L' :      USART_Tx('L');

                   USART_Tx(' ');

                   PORTC=PORTC | 0x04;
                   for(i=0;i<50;i++){
                   PORTC=PORTC | 0x08;
                   MyDelay();
                   PORTC=PORTC & 0xF7;
                   MyDelay();
                   }
                    PORTC=PORTC & 0xFB;
   break;
   case 'U' :
                   USART_Tx('U');

                   USART_Tx(' ');
                   PORTD=PORTD | 0x01;
                   for(i=0;i<50;i++){
                   PORTD=PORTD | 0x02;
                   MyDelay();
                   PORTD=PORTD & 0xFD;
                   MyDelay();
                   }
                    PORTD=PORTD & 0xFE;
   break;
   case 'D' :
                   USART_Tx('D');

                   USART_Tx(' ');
                   PORTD=PORTD | 0x04;
                   for(i=0;i<50;i++){
                   PORTD=PORTD | 0x08;
                   MyDelay();
                   PORTD=PORTD & 0xF7;
                   MyDelay();
                   }
                    PORTD=PORTD & 0xFB;
   break;
   case 'B' :
                   USART_Tx('B');

                   USART_Tx(' ');
                   PORTC=PORTC | 0x01;
                   for(i=0;i<50;i++){
                   PORTC=PORTC | 0x02;
                   MyDelay();
                   PORTC=PORTC & 0xFD;
                   MyDelay();
                   }
                    PORTC=PORTC & 0xFE;
   break;
   default ://case "F" :
                   USART_Tx('F');

                   USART_Tx(' ');
                   PORTD=PORTD | 0x10;
                   for(i=0;i<50;i++){
                   PORTD=PORTD | 0x20;
                   MyDelay();
                   PORTD=PORTD & 0xDF;
                   MyDelay();
                   }
                    PORTD=PORTD & 0xEF;
}}

void Move(unsigned char x){
 switch(x){
   case 'R' :      USART_Tx('R');
                   USART_Tx(0X27);
                   USART_Tx(' ');
                   for(i=0;i<50;i++){
                   PORTC=PORTC | 0x20;
                   MyDelay();
                   PORTC=PORTC & 0xDF;
                   MyDelay();
                 }

   break;
   case 'L' :      USART_Tx('L');
                   USART_Tx(0X27);
                   USART_Tx(' ');


                   for(i=0;i<50;i++){
                   PORTC=PORTC | 0x08;
                   MyDelay();
                   PORTC=PORTC & 0xF7;
                   MyDelay();
                   }

   break;
   case 'U' :
                   USART_Tx('U');
                   USART_Tx(0X27);
                   USART_Tx(' ');

                   for(i=0;i<50;i++){
                   PORTD=PORTD | 0x02;
                   MyDelay();
                   PORTD=PORTD & 0xFD;
                   MyDelay();
                   }

   break;
   case 'D' :
                   USART_Tx('D');
                   USART_Tx(0X27);
                   USART_Tx(' ');

                   for(i=0;i<50;i++){
                   PORTD=PORTD | 0x08;
                   MyDelay();
                   PORTD=PORTD & 0xF7;
                   MyDelay();
                   }

   break;
   case 'B' :
                   USART_Tx('B');
                   USART_Tx(0X27);
                   USART_Tx(' ');

                   for(i=0;i<50;i++){
                   PORTC=PORTC | 0x02;
                   MyDelay();
                   PORTC=PORTC & 0xFD;
                   MyDelay();
                   }

   break;
   default ://case "F" :
                   USART_Tx('F');
                   USART_Tx(0X27);
                   USART_Tx(' ');

                   for(i=0;i<50;i++){
                   PORTD=PORTD | 0x20;
                   MyDelay();
                   PORTD=PORTD & 0xDF;
                   MyDelay();
                   }

}}

void myDelay(){
      cntr=0;
    while(cntr<1);
}

void USART_init(void){
SPBRG = 12; // 9600 bpsXX 600bps
TXSTA = 0x20;// 8-bit, Tx Enable, Asysnc, Low Speed
RCSTA = 0x90;// SP Enable, 8-bi, cont. Rx
TRISC = 0x80;
PIE1 = PIE1 | 0x20;// RCIE
INTCON = 0xC0;}//GIE, PEIE


 void TMR0_init(void){
       OPTION_REG= 0x82;
        sec10m=0;
        sec_1=0;
        sec=0;
        sec10=0;

        tick=0;
        tick2=0;
        tick3=0;
        tick4=0;
        TMR0=58;
         INTCON = INTCON | 0xA0;} // GIE T0IE

void USART_Tx(unsigned char myChar){
while(!(TXSTA & 0x02));
TXREG = myChar;}

void display(unsigned char a,unsigned char b)
    {PORTB=a;
    PORTD.B6=b;
    PORTD.B7=1;
    mymsDelay(10);
    PORTD.B7=0;
    mymsDelay(10);
    PORTB=a<<4;
    PORTD.B6=b;
    PORTD.B7=1;
    mymsDelay(10);
    PORTD.B7=0;
    mymsDelay(10);
    return;
}

void mymsDelay(unsigned int x){
    cntr=0;
    while(cntr<x);

}